class Expense:
    def __init__(self, category, amount):
        self.category = category
        self.amount = amount


class Budget:
    def __init__(self):
        self.income = 0
        self.savings_goal = 0
        self.expenses = []

    def set_income(self, income):
        if income < 0:
            raise ValueError("Income cannot be negative.")
        self.income = income

    def set_savings_goal(self, goal):
        if goal < 0:
            raise ValueError("Savings goal cannot be negative.")
        self.savings_goal = goal

    def add_expense(self, category, amount):
        if amount < 0:
            raise ValueError("Expense cannot be negative.")
        self.expenses.append(Expense(category, amount))

    def total_expenses(self):
        return sum(exp.amount for exp in self.expenses)

    def balance(self):
        return self.income - self.total_expenses()

    def check_savings_goal(self):
        return self.balance() >= self.savings_goal

    def display_summary(self):
        print("\n====== BUDGET SUMMARY ======")
        print(f"Income: {self.income}")
        print(f"Savings Goal: {self.savings_goal}")

        print("\nExpenses:")
        category_totals = {}

        for exp in self.expenses:
            print(f"{exp.category}: {exp.amount}")
            if exp.category in category_totals:
                category_totals[exp.category] += exp.amount
            else:
                category_totals[exp.category] = exp.amount

        print("\n--- Category Breakdown ---")
        for cat, total in category_totals.items():
            print(f"{cat}: {total}")

        print(f"\nTotal Expenses: {self.total_expenses()}")
        print(f"Remaining Balance: {self.balance()}")

        if self.check_savings_goal():
            print("✅ Savings goal achieved!")
        else:
            print("❌ Savings goal not achieved.")


def get_valid_number(prompt):
    while True:
        try:
            value = float(input(prompt))
            if value < 0:
                print("Value must be positive.")
                continue
            return value
        except ValueError:
            print("Invalid input. Enter a number.")


def main():
    budget = Budget()

    # Get income
    income = get_valid_number("Enter your monthly income: ")
    budget.set_income(income)

    # Get savings goal
    goal = get_valid_number("Enter your savings goal: ")
    budget.set_savings_goal(goal)

    # Add expenses
    while True:
        category = input("\nEnter expense category (housing, food, transport, entertainment) or 'done': ")

        if category.lower() == 'done':
            break

        amount = get_valid_number("Enter expense amount: ")
        budget.add_expense(category, amount)

    # Display results
    budget.display_summary()


if __name__ == "__main__":
    main()